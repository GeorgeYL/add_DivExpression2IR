#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/IRBuilder.h"
#include <iostream>
 
using namespace llvm;

int main(int argc, char* argv[])
{
	static LLVMContext MyGlobalContext;
    LLVMContext &context = MyGlobalContext;
	
	//create a module
	Module *module = new Module("fun.c", context);
	
	//declare funtion----------------------------------
	SmallVector<Type *, 3> functionArgs;
    // Parameter type
    functionArgs.push_back(Type::getInt32Ty(context)); // int a
    functionArgs.push_back(Type::getInt32Ty(context)); // int b
	functionArgs.push_back(Type::getFloatTy(context)); // float x
	
	// construct the Function type
	Type *returnType = Type::getFloatTy(context); 
	FunctionType *funcType = FunctionType::get(returnType, functionArgs, /*isVarArg*/ false);
	
	// Function signature
	// declare float fun(int,a int b, float x);
	// Insert a function into module
	// Function *func = cast<Function>(module->getOrInsertFunction("fun", funcType));
	//-----------------------------------------------
	// Create the function
    Function *func = Function::Create(funcType, Function::ExternalLinkage, "fun", module);

	// Function Body-----------------------------------------------
	// Get and save the Parms
	Function::arg_iterator argsIT = func->arg_begin();
	Value *arg_a = argsIT++; // get the first parm
	arg_a->setName("a"); 
	Value *arg_b = argsIT++;
	arg_b->setName("b");
	Value *arg_x = argsIT++;
	arg_x->setName("x");
	
	// create the entry code 
	BasicBlock *entry = BasicBlock::Create(context, "entry", func);
	IRBuilder<> builder_fun(entry); // Every basicblock with need an IRBuilder object

	Value *const_zero = ConstantFP::get(Type::getFloatTy(context), 0.0);
	// create if_then 
	BasicBlock *if_then = BasicBlock::Create(context, "if_then", func);
	IRBuilder<> builder_then(if_then);
	
	// create if_else
	BasicBlock *if_else = BasicBlock::Create(context, "if_else", func);
	IRBuilder<> builder_else(if_else);

    Value *cmp_value = builder_fun.CreateFCmpONE(arg_x, const_zero, "ifcond");

	// if/else condition: cmp_value
	builder_fun.CreateCondBr(cmp_value, if_then, if_else);

	//add arg_a + arg_b
	Value *sum = builder_then.CreateAdd(arg_a, arg_b, "sum");	
	// Generate the IR for (sum / x)
	// (float)sum before dividing.
	Value *fsum = builder_then.CreateSIToFP(sum, returnType, "fsum");
    Value *result = builder_then.CreateFDiv(fsum, arg_x, "result");
	//Value *floatPtr = builder_then.CreateAlloca(Type::getFloatTy(context), nullptr, "floatPtr");
	// Store the float value into allocated memory
    //builder_then.CreateStore(result, floatPtr, false);
	// load it to value
    //Value *retloadedValue = builder_then.CreateLoad(returnType, floatPtr, "retloadedValue");

	// return value
	builder_then.CreateRet(result);
	builder_else.CreateRet(arg_x);	
	
    module->print(outs(), nullptr);
    //---------------------------------------------------
	
	delete module ;
    return 0;
}
