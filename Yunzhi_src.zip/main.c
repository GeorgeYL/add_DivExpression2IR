// main.c
#include <stdio.h>

extern float fun(int a, int b, float x);
int main(int argc, char* argv[])
{

    int a = 5;
    int b = 10;
    float x = 3.0;

    float ret  = fun(a, b, x);
    printf("the (%d + %d)/ %.2f = %.2f\n", a, b, x, ret);

    x = 0.0;
    
    ret  = fun(a, b, x);
    printf("the (%d + %d)/ %.2f = %.2f\n", a, b, x, ret);
    return 0;
}