
float fun(int a, int b, float x)
{
    if((float)0.0 != x)
    {
        return (a+b)/x;
    }
    return (float)0.0;
}